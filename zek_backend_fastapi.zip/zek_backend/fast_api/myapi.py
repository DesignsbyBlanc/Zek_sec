from fastapi import FastAPI
from contextlib import asynccontextmanager
import asyncio
from datetime import datetime
import subprocess
import json
script_to_run = '/Users/terryblanc/CodeBase/z_gemini/zek_backend/gemini_utils/query_file.py'

# Global variable to store the data
data = {"last_updated": None, "value": 0}

async def update_data():
    while True:
        data["last_updated"] = datetime.now().isoformat()
        data["value"] += 1
        # try:
            # Run the Python script
        result = subprocess.run(['python', script_to_run], check=False, capture_output=False, text=False)
    
            # # Print the standard output and error of the executed script
            # print("Output:\n", result.stdout)
            # print("Error:\n", result.stderr)

        # except subprocess.CalledProcessError as e:
        #     print(f"An error occurred while running the script: {e}")
        
        with open("./chat_response.json", "r") as f:
            chat_resp = json.load(f)
        data["Chat"] = chat_resp
        await asyncio.sleep(60)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Start the background task
    task = asyncio.create_task(update_data())
    yield
    # Cancel the background task when the app is shutting down
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        pass

app = FastAPI(lifespan=lifespan)

@app.get("/data")
async def get_data():
    return data