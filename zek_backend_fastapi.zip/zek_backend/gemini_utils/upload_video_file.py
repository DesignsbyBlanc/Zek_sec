import google.generativeai as genai
from env_local import GOOGLE_API_KEY
import time
from file_utils.get_folder_files import all_folder_files

def up_files_genai():
    genai.configure(api_key=GOOGLE_API_KEY)

    folder_name = "/Users/terryblanc/CodeBase/z_gemini/zek_backend/stream_server/test_stream/mp4/"

    streams = all_folder_files(folder=folder_name, file_extension="mp4")
    dc_of_uploads = {}

    for s in streams:
        print(f"\n Uploading file... \n")
        video_file = genai.upload_file(path=s)
        print(video_file)
        print(f"Completed upload: {video_file.uri}")
        dc_of_uploads[video_file.display_name] = video_file

        while video_file.state.name == "PROCESSING":
            print('.', end='')
            time.sleep(10)
            video_file = genai.get_file(video_file.name)


        if video_file.state.name == "FAILED":
            raise ValueError(video_file.state.name)

    return dc_of_uploads

if __name__ == "__main__":
    print("\n ALL DONE! \n", up_files_genai())