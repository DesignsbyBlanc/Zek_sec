import google.generativeai as genai
from env_local import GOOGLE_API_KEY
def delete_all_files():
    genai.configure(api_key=GOOGLE_API_KEY)

    print("My files:")
    for f in genai.list_files():
        print(f"\n File info: {f}")
        print("\n deleting: ", f.name)
        f.delete()

if __name__ == "__main__":
    delete_all_files()