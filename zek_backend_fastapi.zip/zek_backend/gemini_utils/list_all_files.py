import google.generativeai as genai
from env_local import GOOGLE_API_KEY

def all_uploaded_files(should_print:bool):
    genai.configure(api_key=GOOGLE_API_KEY)

    all_files = {}

    print("My files:")
    for f in genai.list_files():
        if should_print:
            print(f"File info: {f}")
        all_files[f.display_name] = f
    if should_print:
        print(all_files)
    return all_files

if __name__ == "__main__":
    all_uploaded_files(True)
