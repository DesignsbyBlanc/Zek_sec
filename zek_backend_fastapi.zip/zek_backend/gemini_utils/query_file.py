import google.generativeai as genai
from env_local import GOOGLE_API_KEY
import time
from list_all_files import all_uploaded_files
import json
import os

def main():
    genai.configure(api_key=GOOGLE_API_KEY)


    filey = all_uploaded_files(False)

    for name, fileobj in filey.items():
        print("File name:", name)
    
    if not os.environ["QUERY_GO"]:
        chosen_file = input("Pick a file to query: ").lower()
        query(filey,chosen_file)
    query(filey)

def query(filey, chosen_file="segment_2.mp4"):
    try:
        if filey[chosen_file]:
            # Create the prompt.
            prompt = "Describe this video. Use the date and time stamp as for bullet points"

            # Set the model to Gemini 1.5 Pro.
            model = genai.GenerativeModel(model_name="models/gemini-1.5-pro-latest")

            # Make the LLM request.
            print("Making LLM inference request...")
            response = model.generate_content([prompt, filey[chosen_file]],
                                            request_options={"timeout": 600})
            
            with open("/Users/terryblanc/CodeBase/z_gemini/zek_backend/fast_api/chat_response.json", 'w') as file:
                json.dump(response.text, file, indent=4)
            # print(response.text)
            # return(response.text)
    except Exception as e:
        print(f"File does {e} not exist")

if __name__ == "__main__":
    main()  