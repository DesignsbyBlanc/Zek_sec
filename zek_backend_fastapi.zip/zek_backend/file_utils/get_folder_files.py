import os 

def all_folder_files(file_path="" , file_extension="", folder="") :
    """ This function will get all files in the folder of the file path provided """
    folder_dir = ""
    folder_files = []
    # Read the playlist file
    if file_extension.lower() == "ts" and file_path:
        with open(file_path, 'r') as file:
            lines = file.readlines()
            # print(lines, "\n")

        for line in lines:
            if line.strip().endswith(file_extension.lower()):
                # print(line)
                if folder_dir:
                    pass
                else:
                    folder_dir = file_path[:-(len(line.strip())+1)]
                folder_files.append(
                    folder_dir + line.strip())

        # print("Files: ", folder_files, "PWD:", folder_dir)
        return (folder_files, folder_dir )
    else:
        folder_dir = folder
        for filename in os.listdir(folder):
            if filename.endswith(file_extension):
                folder_files.append((folder_dir + filename))
        return (folder_files)


# playlist_folder = '/Users/terryblanc/CodeBase/z_gemini/zek_backend/stream_server/test_stream/'

# # Path to the HLS playlist file (stream.m3u8)
# playlist_path = playlist_folder + 'stream.m3u8'
# print("File path entered: ", playlist_path, "\n")

# all_folder_files(playlist_path, "ts")
