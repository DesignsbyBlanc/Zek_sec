import ffmpeg
import os
from get_folder_files import all_folder_files

# Function to convert HLS segment to MP4


def convert_to_mp4(segment, output_name):
    (
        ffmpeg
        .input(segment)
        .output(output_name, c='copy')
        .run()
    )


playlist_folder = '/Users/terryblanc/CodeBase/z_gemini/zek_backend/stream_server/test_stream/'

# # Path to the HLS playlist file (stream.m3u8)
playlist_path = playlist_folder + 'stream.m3u8'

(files, dir) =  all_folder_files(playlist_path, "ts")

# Convert the first 5 segments to MP4
for i, fi in enumerate(files):
    output_name = f'{dir}mp4/segment_{i+1}.mp4'
    convert_to_mp4(fi, output_name)
    print(f'Converted {fi} to {output_name}')
